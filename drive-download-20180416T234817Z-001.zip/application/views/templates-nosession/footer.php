<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Student Time Planner 2018</p>
      </div>
      <!-- /.container -->
    </footer>

  </body>

</html>
